import bg.sofia.uni.fmi.mjt.order.client.TShirtsClient;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

class TShirtsClientTest {
    @Test
    public void testThrowsRuntimeException() {
        assertThrows(RuntimeException.class, () -> TShirtsClient.main(null));
    }
}
