package bg.sofia.uni.fmi.mjt.order.client.tshirt;

public record TShirt(Size size, Color color) {
}
